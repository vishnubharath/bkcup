package com.test.automation.AutomateTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutomateTestApplicationTests {

	@Test
	void test1() {
		for (int i = 0; i < 10; i++) {
			System.out.println("1");
		}
	}

}
