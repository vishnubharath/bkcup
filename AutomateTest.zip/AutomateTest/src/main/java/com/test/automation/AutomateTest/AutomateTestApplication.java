package com.test.automation.AutomateTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutomateTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutomateTestApplication.class, args);
	}

}
